---
name: send-available-report
description: "Build the available-time performance report from a new Daily Activity Log CSV, create individual and manager workbooks, and send the resulting links to agents and the XA team-lead Slack channel when explicitly requested."
---

# Send Available Report

Use this skill when the user supplies a new Daily Activity Log CSV and asks to send the available-time report, especially with the exact prompt: **Send Available report to all agents**.

## Build the report

1. Identify the requested CSV. If the user names a file, use that file. Otherwise select the newest `Daily Activity Log by Agent (*.csv)` in Downloads and show the selected filename before sending.
2. Use the existing `agent-performance-report` workflow and the schedule/timezone rules in [references/schedule-rules.md](references/schedule-rules.md). Preserve the report's in-progress-date handling: keep the newest partial date visible, but exclude it from completed-shift averages and completed totals.
3. Recalculate and independently verify the workbook before any external send. A failed verification, missing formula caches, or materially ambiguous source issue must not be sent. Normal audit warnings such as an in-progress date, schedule offsets, or roster-only agents may remain when they are clearly surfaced in the report.
4. Add the following to every agent workbook and the manager workbook:
   - `Team Avg Available %`
   - `Agent Available %`
   - `Difference (pp)`
   - `Target Available %` fixed at 70.00%
   - Daily `OT Time` using `MAX(0, Total Logged Time - Lunch - 8:00)` and a completed-day OT total at the bottom.
   Do not add relative difference unless the user asks for it.
5. Produce one individual workbook per report agent and one full manager workbook containing all agent tabs plus `Team Summary`. Keep no-data agents in the package and mark their metrics as unavailable rather than inventing values.
6. Validate the package before publishing: each individual workbook must contain exactly one agent sheet, that sheet's title must match the intended recipient, and it must not contain `Team Summary` or any other agent's data. The manager workbook is the only workbook allowed to contain all agents.

## Publish and send

The exact send prompt is authorization to send. Do not send anything for a request that only says prepare, build, or export.

Before sending, publish the manager workbook and each individual workbook through the connected Google Drive/Sheets workflow so recipients receive accessible links; never send local filesystem paths. Preserve the generated Excel files as downloadable artifacts as well.

For `Send Available report to all agents`:

- Resolve each report agent to exactly one Slack person by display name. If a name is ambiguous or cannot be found, stop before sending and report the unresolved names.
- Send one direct Slack message to each agent with only that exact agent's individual report link. Match the recipient name, workbook filename, and sole workbook sheet title before sending. Never include the manager workbook, a ZIP of all reports, or another agent's link in a direct message.
- Post the full manager report link, and only the full manager report link, once in `#XA-Team-Lead-Private`.
- Do not send duplicate messages if the same request is retried; inspect the current send status or ask the user before resending.
- Afterward, report the exact successful recipients, any failures, the channel-post result, and the manager/individual links. Never claim delivery from a draft or a failed connector response.

If the user asks to prepare without sending, complete the workbooks and links but do not call Slack send or post tools.
