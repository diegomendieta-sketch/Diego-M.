# Available report schedule rules

This shareable copy uses fictional agent names and aliases consistently with the bundled roster. Replace them with your own roster mappings before running a real report. `<REPORT_PROJECT_DIR>` means your local report-project directory; its external scope JSON is not bundled here.

The schedule table's first time range is Pacific time and its second time range is Eastern time. Use the timezone explicitly assigned below for schedule start/end and for converting raw activity timestamps. The MIA agents marked EST in the source table and confirmed new-hire updates have raw activity timestamps shifted three hours from Pacific to Eastern.

## EST agents

- Example Agent 002
- Example Agent 011
- Example Agent 013
- Example Agent 014 (source alias: Example Agent 014 Source Alias)
- Example Agent 009
- Example Agent 012 (log name: Example Agent 012 Log Alias)
- Example Agent 005
- Example Agent 010
- Example Agent 001

For Example Agent 005, after using the EST schedule, subtract 30 minutes from the scheduled end time. The current corrected EST schedule is 10:00–18:00.


## New hires confirmed November 16, 2026

| Agent | Timezone | Scheduled start | Scheduled end |
| --- | --- | --- | --- |
| Example Agent 015 | EST | 11:00 AM | 7:30 PM |
| Example Agent 016 | EST | 1:30 PM | 10:00 PM |
| Example Agent 017 | EST | 1:00 PM | 10:00 PM |

All three use Eastern time; add three hours to their Pacific activity timestamps, following the established report rule. Merge these rows into the selected current roster, rather than dropping them when using an older bundled roster. Shift hours were explicitly confirmed by the user. The saved November 12 staffing roster lists Example Agent 015 and Example Agent 016 working Monday, Tuesday, Wednesday, Friday, and Saturday, and Example Agent 017 working Friday through Tuesday. Preserve those workdays unless the user supplies an update.

## PST agents

- Example Agent 007
- Example Agent 018
- Example Agent 019
- Example Agent 008
- Example Agent 020 (source alias: Example Agent 020 Source Alias)
- Example Agent 004
- Example Agent 021
- Example Agent 022
- Example Agent 006
- Example Agent 003
- Example Agent 023

Example Agent 022 has no timezone suffix in the supplied table; use PST only when the user has not supplied a newer correction. If the user supplies a different timezone, use the newer instruction.

## Other rules

- Preserve each person's stated workweek and days off. Work recorded on a day off remains visible and is included in the OT calculation.
- Treat `Example Agent 014 Source Alias` as `Example Agent 014` and `Example Agent 020 Source Alias` as `Example Agent 020` when matching the activity log and roster.
- The PM schedule typo `1:30am` should be treated as `1:30pm` when the user has confirmed that correction; otherwise ask before building because it changes the shift length materially.

## Agent report exclusions updated November 16, 2026

- Exclude Example Agent 022, Example Agent 018, and Example Agent 021 from agent workbooks, agent tabs, and team performance averages because they are team leads. Keep their separately authorized management-report access.
- Exclude Example Agent 024 from all further report processing unless the user explicitly requests her inclusion again.
- These people may appear in historical schedule tables or older reports; those historical entries do not override the current exclusions.
- The current report scope is saved in `<REPORT_PROJECT_DIR>/data/current_agent_report_scope.json`. Apply exclusions to both roster and source events so ingestion cannot add them back as log-only agents.
