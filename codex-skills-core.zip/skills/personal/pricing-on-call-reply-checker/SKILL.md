---
name: pricing-on-call-reply-checker
description: Find pricing-team requests in the #pricing-on-call chat that tag @XAteam, then report each request's thread link and whether the thread has a reply.
---

# Pricing On Call Reply Checker

Use this skill when the user asks for a current audit, list, or follow-up check of pricing requests posted in `#pricing-on-call` that tag `@XAteam`.

## Scope and matching

- Use the connected chat/search integration available in the environment. Treat `#pricing-on-call` as the required channel; do not substitute similarly named channels.
- Search the channel's available history for messages that contain the actual `@XAteam` mention. Do not match plain text such as `XAteam`, `@XA team`, or an unrelated XA mention.
- Include only requests posted by the pricing team. Use the sender's team identity or the connected directory/profile data when available. If the sender cannot be verified as pricing, exclude it or clearly label it as `team identity unverified` rather than silently treating it as a pricing request.
- Treat the matching channel message as the thread root. Deduplicate by thread/root message so a thread is listed once even if replies also contain `@XAteam`.
- Search all available channel history unless the user supplies a date range or cutoff. If the chat integration imposes a search limit, state the covered period or limitation.

## Reply status

- `Replied` means the thread contains at least one actual child message after the root, from any participant.
- `Missing reply` means the root message has no child messages.
- Do not count the root message itself, reactions, read receipts, or other non-message metadata as a reply.
- If the integration cannot inspect thread replies reliably, report `Reply status unavailable` and explain the limitation; do not infer status from channel chronology.

## Output

Return a compact table with one row per matching request, newest first when timestamps are available:

| Posted | Request | Thread | Reply status |
|---|---|---|---|
| timestamp or date | concise summary of the root request | direct link to the thread | `Replied` or `Missing reply` |

Use the platform's direct permalink to the thread/root message. Preserve the request's important details in the summary, but do not reproduce unnecessary message history or private data. Include the author when useful for disambiguation.

If no matching requests are found, say so and include the search scope used. If there are matching requests, finish with a short count of total requests, replied threads, and missing replies. Keep this workflow read-only: do not post, react, or message anyone unless the user separately asks for that action.
