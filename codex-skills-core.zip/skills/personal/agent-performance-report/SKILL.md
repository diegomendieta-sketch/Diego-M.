---
name: agent-performance-report
description: Run the local team activity performance report from a Daily Activity Log CSV and prepare a shareable Excel workbook.
---

# Agent Performance Report

Use this skill when the user asks to run, refresh, or share the team activity performance report.

Run `scripts/run_report.py` from the report project. With no arguments it selects the newest `Daily Activity Log by Agent (*.csv)` file in Downloads, uses the bundled September 2026 roster, excludes the newest activity date from completed-shift averages while keeping it visible as today’s activity, recalculates the workbook, and writes a shareable copy to Downloads.

```sh
cd "<REPORT_PROJECT_DIR>"
python3 skills/agent-performance-report/scripts/run_report.py
```

`<REPORT_PROJECT_DIR>` means your local report-project directory. The bundled roster uses fictional agent names for sharing; supply your current roster for real reports. The separate `agent_report` Python package is required by the runner and is not included in this skill folder.

Use `--log PATH` for a specific export, `--roster PATH` when the schedule changes, `--out PATH` for a custom workbook location, and `--share-copy PATH` for a custom shareable copy. The bundled roster is a dated convenience default; replace it or pass a current roster when schedules change.

The script preserves all status columns, keeps the Team Summary ordering with availability/time first, adherence next, and calls after, and reports whether recalculation completed. If the source contains a known data-quality exception such as a shift over the 15-hour guard, the workbook is still produced but must be described as unverified.
