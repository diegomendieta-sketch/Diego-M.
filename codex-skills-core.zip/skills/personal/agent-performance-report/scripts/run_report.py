#!/usr/bin/env python3
"""Build a shareable team report from the newest activity export."""
from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[3]
DEFAULT_ROSTER = Path(__file__).resolve().parents[1] / "assets" / "team_roster.csv"
sys.path.insert(0, str(PROJECT))

from agent_report.ingest import load_log, load_roster  # noqa: E402
from agent_report.recalculate import recalculate, scan  # noqa: E402
from agent_report.rules import calculate  # noqa: E402
from agent_report.workbook import create_workbook  # noqa: E402


def newest_log(downloads: Path) -> Path:
    candidates = list(downloads.glob("Daily Activity Log by Agent (*.csv)"))
    if not candidates:
        raise FileNotFoundError(f"No Daily Activity Log by Agent CSV found in {downloads}")
    return max(candidates, key=lambda p: p.stat().st_mtime)


def build(log: Path, roster: Path, out: Path):
    report = calculate(load_log(log), load_roster(roster))
    latest = max(r["date"] for r in report["records"])
    today = [r for r in report["records"] if r["date"] == latest]
    for record in today:
        record["in_progress"] = True
        record["end_band"] = None
    report["progress_date"] = latest
    report["flags"].append({"code": "in_progress", "agent": None, "date": latest,
                            "detail": f"{latest} excluded from completed-shift averages as the current report date"})
    out.parent.mkdir(parents=True, exist_ok=True)
    create_workbook(report, out)
    warnings = recalculate(out)
    scan(out, require_cache=not warnings)
    return out, len(today), sum(not r["in_progress"] for r in report["records"]), warnings


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--log", type=Path)
    parser.add_argument("--roster", type=Path, default=DEFAULT_ROSTER)
    parser.add_argument("--out", type=Path, default=PROJECT / "outputs" / "Team_Performance_Report.xlsx")
    parser.add_argument("--share-copy", type=Path,
                        default=Path.home() / "Downloads" / "Team_Performance_Report.xlsx")
    args = parser.parse_args()
    log = args.log or newest_log(Path.home() / "Downloads")
    if not args.roster.exists():
        raise FileNotFoundError(f"Roster not found: {args.roster}; pass --roster with the current schedule CSV")
    out, today_count, completed_count, warnings = build(log, args.roster, args.out)
    args.share_copy.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(out, args.share_copy)
    print(f"Source: {log}")
    print(f"Workbook: {out}")
    print(f"Share copy: {args.share_copy}")
    print(f"Current-date rows excluded from averages: {today_count}")
    print(f"Completed records used in averages: {completed_count}")
    print(f"Formula recalculation warnings: {len(warnings)}")
    print("Verification: not run because the current-date override is intentionally excluded from completed-shift averages.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)
