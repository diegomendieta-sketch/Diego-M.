# Diego’s Codex Skills

Snapshot of all 61 skill folders found in the local Codex skills directory and plugin cache on November 17, 2026. Includes 11 personal skills, 5 system skills, and 45 plugin skills. Active, legacy, and cached template skill folders are included; presence here does not imply that a plugin is currently enabled.

Each skill includes its `SKILL.md` and the scripts, references, templates, and assets stored with it. Existing license and notice files are preserved. See [manifest](skills/manifest.json), [file checksums](skills/SHA256SUMS), and [sanitization notes](SANITIZATION.md).

## Using this snapshot

Browse the index below to open a skill. To restore a personal skill, copy its entire folder from `skills/personal/` into your Codex skills directory. System and plugin folders are organized by their original source; restore or enable the associated plugin for its tools and runtime dependencies.

Plugin connections, account permissions, credentials, runtime libraries, and unrelated project files are not included. Some skills need connected apps or an external runtime. In particular, the performance report skills require the separate `agent_report` project and current report-scope configuration. Replace documented placeholders with your own configuration before using them.

Customer case examples and staff names in personal skills are anonymized for this public copy. Local originals were not changed. Staff schedule rows retain their structure but must be configured for your team.

## Skill index

### Personal skills (11)

| Skill | Source |
| --- | --- |
| [agent-performance-report](skills/personal/agent-performance-report/SKILL.md) | Personal |
| [agent-verification](skills/personal/agent-verification/SKILL.md) | Personal |
| [hatch-pet](skills/personal/hatch-pet/SKILL.md) | Personal |
| [opshub-context](skills/personal/opshub-context/SKILL.md) | Personal |
| [pricing-on-call-reply-checker](skills/personal/pricing-on-call-reply-checker/SKILL.md) | Personal |
| [schedule-final-offer-appointment](skills/personal/schedule-final-offer-appointment/SKILL.md) | Personal |
| [send-available-report](skills/personal/send-available-report/SKILL.md) | Personal |
| [xa-admin-account-merge](skills/personal/xa-admin-account-merge/SKILL.md) | Personal |
| [xa-notes](skills/personal/xa-notes/SKILL.md) | Personal |
| [xa-quick-slack](skills/personal/xa-quick-slack/SKILL.md) | Personal |
| [zendesk-record-retrieval](skills/personal/zendesk-record-retrieval/SKILL.md) | Personal |

### System skills (5)

| Skill | Source |
| --- | --- |
| [imagegen](skills/system/imagegen/SKILL.md) | Codex system |
| [openai-docs](skills/system/openai-docs/SKILL.md) | Codex system |
| [review-agent](skills/system/review-agent/SKILL.md) | Codex system |
| [skill-creator](skills/system/skill-creator/SKILL.md) | Codex system |
| [skill-installer](skills/system/skill-installer/SKILL.md) | Codex system |

### Plugin skills (45)

| Skill | Source |
| --- | --- |
| [visualize](skills/plugins/openai-bundled/visualize/1.0.55/skills/visualize/SKILL.md) | visualize/1.0.55 |
| [google-docs](skills/plugins/openai-curated-remote/google-drive/0.1.23/skills/google-docs/SKILL.md) | google-drive/0.1.23 |
| [google-drive](skills/plugins/openai-curated-remote/google-drive/0.1.23/skills/google-drive/SKILL.md) | google-drive/0.1.23 |
| [google-drive-comments](skills/plugins/openai-curated-remote/google-drive/0.1.23/skills/google-drive-comments/SKILL.md) | google-drive/0.1.23 |
| [google-sheets](skills/plugins/openai-curated-remote/google-drive/0.1.23/skills/google-sheets/SKILL.md) | google-drive/0.1.23 |
| [google-slides](skills/plugins/openai-curated-remote/google-drive/0.1.23/skills/google-slides/SKILL.md) | google-drive/0.1.23 |
| [artifact-template-analytics-dashboard](skills/plugins/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-analytics-dashboard/SKILL.md) | openai-templates/0.1.1 |
| [artifact-template-business-review](skills/plugins/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-business-review/SKILL.md) | openai-templates/0.1.1 |
| [artifact-template-design-report](skills/plugins/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-design-report/SKILL.md) | openai-templates/0.1.1 |
| [artifact-template-experiment-analysis](skills/plugins/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-experiment-analysis/SKILL.md) | openai-templates/0.1.1 |
| [artifact-template-financial-budget](skills/plugins/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-financial-budget/SKILL.md) | openai-templates/0.1.1 |
| [artifact-template-investment-committee-memo](skills/plugins/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-investment-committee-memo/SKILL.md) | openai-templates/0.1.1 |
| [artifact-template-legal-memorandum](skills/plugins/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-legal-memorandum/SKILL.md) | openai-templates/0.1.1 |
| [artifact-template-market-trends-report](skills/plugins/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-market-trends-report/SKILL.md) | openai-templates/0.1.1 |
| [artifact-template-minimal-letterhead](skills/plugins/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-minimal-letterhead/SKILL.md) | openai-templates/0.1.1 |
| [artifact-template-operating-calendar](skills/plugins/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-operating-calendar/SKILL.md) | openai-templates/0.1.1 |
| [artifact-template-operating-review](skills/plugins/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-operating-review/SKILL.md) | openai-templates/0.1.1 |
| [artifact-template-project-kickoff](skills/plugins/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-project-kickoff/SKILL.md) | openai-templates/0.1.1 |
| [artifact-template-project-tracker](skills/plugins/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-project-tracker/SKILL.md) | openai-templates/0.1.1 |
| [artifact-template-sales-pipeline](skills/plugins/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-sales-pipeline/SKILL.md) | openai-templates/0.1.1 |
| [artifact-template-simple-dark-mode](skills/plugins/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-simple-dark-mode/SKILL.md) | openai-templates/0.1.1 |
| [artifact-template-simple-light-mode](skills/plugins/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-simple-light-mode/SKILL.md) | openai-templates/0.1.1 |
| [artifact-template-strategy-memorandum](skills/plugins/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-strategy-memorandum/SKILL.md) | openai-templates/0.1.1 |
| [artifact-template-system-design](skills/plugins/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-system-design/SKILL.md) | openai-templates/0.1.1 |
| [artifact-template-team-alignment](skills/plugins/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-team-alignment/SKILL.md) | openai-templates/0.1.1 |
| [artifact-template-three-statement-forecast](skills/plugins/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-three-statement-forecast/SKILL.md) | openai-templates/0.1.1 |
| [maintain-space](skills/plugins/openai-curated-remote/pages/0.1.26/skills/maintain-space/SKILL.md) | pages/0.1.26 |
| [manage-schedules](skills/plugins/openai-curated-remote/pages/0.1.26/skills/manage-schedules/SKILL.md) | pages/0.1.26 |
| [organize-space](skills/plugins/openai-curated-remote/pages/0.1.26/skills/organize-space/SKILL.md) | pages/0.1.26 |
| [write-page](skills/plugins/openai-curated-remote/pages/0.1.26/skills/write-page/SKILL.md) | pages/0.1.26 |
| [create-plugin](skills/plugins/openai-curated-remote/plugin-creator/0.1.28/skills/create-plugin/SKILL.md) | plugin-creator/0.1.28 |
| [prepare-plugin-submission](skills/plugins/openai-curated-remote/plugin-creator/0.1.28/skills/prepare-plugin-submission/SKILL.md) | plugin-creator/0.1.28 |
| [update-plugin](skills/plugins/openai-curated-remote/plugin-creator/0.1.28/skills/update-plugin/SKILL.md) | plugin-creator/0.1.28 |
| [plugin-management](skills/plugins/openai-curated-remote/plugin-management/0.1.0/skills/plugin-management/SKILL.md) | plugin-management/0.1.0 |
| [sites](skills/plugins/openai-curated-remote/sites/1.1.6/skills/sites/SKILL.md) | sites/1.1.6 |
| [sites-remix](skills/plugins/openai-curated-remote/sites/1.1.6/skills/sites-remix/SKILL.md) | sites/1.1.6 |
| [create-pet](skills/plugins/openai-curated-remote/work-pets/0.1.6/skills/create-pet/SKILL.md) | work-pets/0.1.6 |
| [pets](skills/plugins/openai-curated-remote/work-pets/0.1.6/skills/pets/SKILL.md) | work-pets/0.1.6 |
| [update-pet](skills/plugins/openai-curated-remote/work-pets/0.1.6/skills/update-pet/SKILL.md) | work-pets/0.1.6 |
| [documents](skills/plugins/openai-primary-runtime/documents/26.1026.10807/skills/documents/SKILL.md) | documents/26.1026.10807 |
| [pdf](skills/plugins/openai-primary-runtime/pdf/26.1026.10807/skills/pdf/SKILL.md) | pdf/26.1026.10807 |
| [Presentations](skills/plugins/openai-primary-runtime/presentations/26.1026.10807/skills/presentations/SKILL.md) | presentations/26.1026.10807 |
| [excel-live-control](skills/plugins/openai-primary-runtime/spreadsheets/26.1026.10807/skills/excel-live-control/SKILL.md) | spreadsheets/26.1026.10807 |
| [Spreadsheets](skills/plugins/openai-primary-runtime/spreadsheets/26.1026.10807/skills/spreadsheets/SKILL.md) | spreadsheets/26.1026.10807 |
| [template-creator](skills/plugins/openai-primary-runtime/template-creator/26.1026.10807/skills/template-creator/SKILL.md) | template-creator/26.1026.10807 |

## Licensing

Licenses and notices supplied with individual skills remain applicable. This snapshot does not grant a new blanket license or transfer rights to bundled third-party material.
